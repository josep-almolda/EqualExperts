﻿using System;
using System.Collections.Generic;
using System.Linq;
using ShoppingCart.Models;

namespace ShoppingCart
{
    public class ShoppingCart
    {
        public List<Item> CartItems { get; } = new List<Item>();
        public decimal Tax { get; }

        public ShoppingCart()
        {
            Tax = 0.0M;
        }

        public ShoppingCart(decimal tax)
        {
            Tax = tax;
        }

        public void AddItem(Product product, int quantity)
        {
            if (!CartItems.Exists(item => item.Product.Name == product.Name))
            {
                CartItems.Add(new Item
                {
                    Product = product,
                    Quantity = quantity
                });
            }
            else
            {
                CartItems.Find(item => item.Product.Name == product.Name).Quantity += quantity;
            }
        }

        public decimal CalculateTotalPrice()
        {
            var totalPrice = CartItems.Sum(x => x.Product.Price * x.Quantity);
            return Math.Round(totalPrice + (totalPrice * Tax / 100), 2);
        }

        public decimal CalculateTotalTax()
        {
            var totalPrice = CartItems.Sum(x => x.Product.Price * x.Quantity);
            return Math.Round(totalPrice * Tax / 100, 2);
        }
    }
}
