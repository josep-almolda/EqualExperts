using System.Linq;
using ShoppingCart.Models;
using Xunit;

namespace ShoppingCartTests
{
    public class IntegrationTests
    {
        [Fact]
        public void WhenAddProductsToEmptyCartThenCartUpdatesProductQuantities()
        {
            // Arrange
            var doveSoap = new Product {Name = "Dove Soap", Price = 39.99M};
            var systemUnderTest = new ShoppingCart.ShoppingCart();

            // Act
            systemUnderTest.AddItem(doveSoap, 5);

            // Assert
            Assert.True(systemUnderTest.CartItems.Count == 1);
            Assert.True(systemUnderTest.CartItems.First().Product.Name == "Dove Soap");
            Assert.True(systemUnderTest.CartItems.First().Product.Price == 39.99M);
            Assert.True(systemUnderTest.CartItems.First().Quantity == 5);
        }

        [Fact]
        public void WhenAddProductsToEmptyCartThenCartUpdatesTotalPrice()
        {
            // Arrange
            var doveSoap = new Product { Name = "Dove Soap", Price = 39.99M };
            var systemUnderTest = new ShoppingCart.ShoppingCart();

            // Act
            systemUnderTest.AddItem(doveSoap, 5);

            // Assert
            Assert.True(systemUnderTest.CalculateTotalPrice() == 199.95M);
        }

        [Fact]
        public void WhenAddProductAlreadyInCartThenCartUpdatesProductQuantities()
        {
            // Arrange
            var doveSoap = new Product { Name = "Dove Soap", Price = 39.99M };
            var systemUnderTest = new ShoppingCart.ShoppingCart();

            // Act
            systemUnderTest.AddItem(doveSoap, 5);
            systemUnderTest.AddItem(doveSoap, 3);

            // Assert
            Assert.True(systemUnderTest.CartItems.Count == 1);
            Assert.True(systemUnderTest.CartItems.First().Product.Name == "Dove Soap");
            Assert.True(systemUnderTest.CartItems.First().Product.Price == 39.99M);
            Assert.True(systemUnderTest.CartItems.First().Quantity == 8);

        }

        [Fact]
        public void WhenAddProductsAlreadyInCartThenCartUpdatesTotalPrice()
        {
            // Arrange
            var doveSoap = new Product { Name = "Dove Soap", Price = 39.99M };
            var systemUnderTest = new ShoppingCart.ShoppingCart();

            // Act
            systemUnderTest.AddItem(doveSoap, 5);
            systemUnderTest.AddItem(doveSoap, 3);

            // Assert
            Assert.True(systemUnderTest.CalculateTotalPrice() == 319.92M);
        }

        [Fact]
        public void WhenAddMultipleItemsInCartThenCartUpdatesProductQuantities()
        {
            // Arrange
            var doveSoap = new Product { Name = "Dove Soap", Price = 39.99M };
            var axeDeo = new Product { Name = "Axe Deo", Price = 99.99M };
            var systemUnderTest = new ShoppingCart.ShoppingCart();

            // Act
            systemUnderTest.AddItem(doveSoap, 2);
            systemUnderTest.AddItem(axeDeo, 2);

            // Assert
            Assert.True(systemUnderTest.CartItems.Count == 2);
            Assert.True(systemUnderTest.CartItems[0].Product.Name == "Dove Soap");
            Assert.True(systemUnderTest.CartItems[0].Product.Price == 39.99M);
            Assert.True(systemUnderTest.CartItems[0].Quantity == 2);

            Assert.True(systemUnderTest.CartItems[1].Product.Name == "Axe Deo");
            Assert.True(systemUnderTest.CartItems[1].Product.Price == 99.99M);
            Assert.True(systemUnderTest.CartItems[1].Quantity == 2);

        }

        [Fact]
        public void WhenAddMultipleItemsInCartWithTaxThenCartUpdatesTotalPrice()
        {
            // Arrange
            var doveSoap = new Product { Name = "Dove Soap", Price = 39.99M };
            var axeDeo = new Product { Name = "Axe Deo", Price = 99.99M };
            const decimal tax = 12.5M;
            var systemUnderTest = new ShoppingCart.ShoppingCart(tax);

            // Act
            systemUnderTest.AddItem(doveSoap, 2);
            systemUnderTest.AddItem(axeDeo, 2);

            // Assert
            Assert.True(systemUnderTest.CalculateTotalPrice() == 314.96M);
        }

        [Fact]
        public void WhenAddMultipleItemsInCartWithTaxThenCartUpdatesTotalTax()
        {
            // Arrange
            var doveSoap = new Product { Name = "Dove Soap", Price = 39.99M };
            var axeDeo = new Product { Name = "Axe Deo", Price = 99.99M };
            const decimal tax = 12.5M;
            var systemUnderTest = new ShoppingCart.ShoppingCart(tax);

            // Act
            systemUnderTest.AddItem(doveSoap, 2);
            systemUnderTest.AddItem(axeDeo, 2);

            // Assert
            Assert.True(systemUnderTest.CalculateTotalTax() == 35.00M);
        }

    }
}
