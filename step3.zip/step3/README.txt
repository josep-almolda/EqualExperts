version:
627d7be039e0085025a51d47e42bdd970409ec1c

this project will run un a windows machine with .NET Core installed
to install .net Core go to the following url and follow the instructions:
https://dotnet.microsoft.com/download

how to run from the command line:
- navigate to the root folder of the project with in a CMD window
- execute the file run_tests.cmd to build the project and execute the tests:
	> run_tests
	
how to run from Visual Studio 2017:
- open the solution file (ShoppingCart.sln) in VS 2017
- go to Test -> Run -> All Tests