using System.Linq;
using ShoppingCart.Models;
using Xunit;

namespace ShoppingCartTests
{
    public class IntegrationTests
    {
        [Fact]
        public void WhenAddProductsToEmptyCartThenCartUpdatesProductQuantities()
        {
            // Arrange
            var doveSoap = new Product {Name = "Dove Soap", Price = 39.99M};
            var systemUnderTest = new ShoppingCart.ShoppingCart();

            // Act
            systemUnderTest.AddItem(doveSoap, 5);

            // Assert
            Assert.True(systemUnderTest.CartItems.Count == 1);
            Assert.True(systemUnderTest.CartItems.First().Product.Name == "Dove Soap");
            Assert.True(systemUnderTest.CartItems.First().Product.Price == 39.99M);
            Assert.True(systemUnderTest.CartItems.First().Quantity == 5);
        }

        [Fact]
        public void WhenAddProductsToEmptyCartThenCartUpdatesTotalPrice()
        {
            // Arrange
            var doveSoap = new Product { Name = "Dove Soap", Price = 39.99M };
            var systemUnderTest = new ShoppingCart.ShoppingCart();

            // Act
            systemUnderTest.AddItem(doveSoap, 5);

            // Assert
            Assert.True(systemUnderTest.CalculateTotalPrice() == 199.95M);
        }
    }
}
