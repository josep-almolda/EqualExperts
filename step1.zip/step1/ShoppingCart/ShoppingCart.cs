﻿using System;
using System.Collections.Generic;
using System.Linq;
using ShoppingCart.Models;

namespace ShoppingCart
{
    public class ShoppingCart
    {
        public List<Item> CartItems { get; } = new List<Item>();

        public void AddItem(Product product, int quantity)
        {
            CartItems.Add(new Item
            {
                Product = product,
                Quantity = quantity
            });
        }

        public decimal CalculateTotalPrice()
        {
            var totalPrice = CartItems.Sum(x => x.Product.Price * x.Quantity);
            return Math.Round(totalPrice, 2);
        }
    }
}
